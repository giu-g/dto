package com.giulia.DTO.dto;

public record LivroDTO(Long id, String titulo, String autor) {

}
