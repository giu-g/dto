package com.giulia.DTO.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.giulia.DTO.entities.Livro;

public interface LivroRepository extends JpaRepository<Livro,Long> {

}
